<?php
	define("db_host","localhost");
	define("db_uid","meetapp_tung");
	define("db_pwd","Ko1aibiet");
	define("db_name","meetapp");
	
	$db = new mysqli(db_host,db_uid,db_pwd,db_name);
?>