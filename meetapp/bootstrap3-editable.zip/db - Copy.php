<?php
	define("db_host","localhost");
	define("db_uid","khactung");
	define("db_pwd","A0116724J");
	define("db_name","khactung");
	
	$db = new mysqli(db_host,db_uid,db_pwd,db_name);
?>